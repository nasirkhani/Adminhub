from prometheus_client import Counter, Histogram, Gauge
import time

# Define metrics
TRANSACTION_COUNTER = Counter(
    'iso8583_transactions_total',
    'Total number of ISO8583 transactions processed',
    ['mti', 'response_code']
)

TRANSACTION_LATENCY = Histogram(
    'iso8583_transaction_duration_seconds',
    'Transaction processing duration in seconds',
    ['mti'],
    buckets=[.005, .01, .025, .05, .075, .1, .25, .5, .75, 1.0, 2.5, 5.0]
)

TRANSACTION_AMOUNT = Gauge(
    'iso8583_transaction_amount',
    'Transaction amount in base currency',
    ['currency']
)

def record_transaction_metrics(transaction):
    # Record transaction count
    TRANSACTION_COUNTER.labels(
        mti=transaction.mti,
        response_code=transaction.response_code
    ).inc()
    
    # Record latency
    TRANSACTION_LATENCY.labels(
        mti=transaction.mti
    ).observe(transaction.duration)
    
    # Record amount
    TRANSACTION_AMOUNT.labels(
        currency=transaction.currency
    ).set(transaction.amount)