@Component
public class ISO8583Processor {
    private static final Logger logger = LoggerFactory.getLogger(ISO8583Processor.class);
    
    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;
    
    @Value("${kafka.topic.iso8583}")
    private String topic;
    
    public void processTransaction(ISO8583Message message) {
        try {
            // Add processing timestamp
            message.setProcessingTimestamp(System.currentTimeMillis());
            
            // Validate message fields
            validateMessage(message);
            
            // Enrich with additional metadata
            enrichMessage(message);
            
            // Send to Kafka
            kafkaTemplate.send(topic, message.getKey(), JsonUtil.toJson(message));
            
            // Record metrics
            recordMetrics(message);
            
        } catch (Exception e) {
            logger.error("Error processing ISO8583 message: {}", e.getMessage());
            throw new TransactionProcessingException(e);
        }
    }
}